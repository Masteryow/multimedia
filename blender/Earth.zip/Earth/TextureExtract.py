"""
Earth — Texture Extract + Color Enhancement
============================================
Blender 5.0

Standalone script — does NOT require Earth.py to have run first.

What this does:
  1. Finds the existing Earth object (named 'Earth')
  2. Extracts all three textures already in the material node tree:
       • earth.jpg   — base color (continents, oceans)
       • clouds.jpg  — subtle cloud overlay
       • night.jpg   — city lights / night-side emission
     Falls back to loading from disk if not found in node tree.
  3. Applies the full cinematic Earth pipeline:
       earth.jpg  → HueSat (deepen blues/greens) → RGB Curves (S-contrast)
       clouds.jpg → MixRGB (10% overlay on day side)
       night.jpg  → Emission (0.5 strength city glow)
       Principled BSDF: ocean specularity via Specular IOR Level
  4. Adds a HueSat boost to make oceans richer and continents more vivid

Nothing else is touched — no mesh rebuild, no animation, no rings
(Earth has no rings).
Re-runnable: safe to run multiple times without duplicating nodes.

Earth texture notes:
  - earth.jpg:  sRGB — day-side base color
  - clouds.jpg: sRGB — white cloud layer, mixed at 10% over base
  - night.jpg:  Non-Color — city lights, drives emission only
"""

import bpy
import os

OBJECT_NAME  = "Earth"
TEXTURE_BASE = r"C:\Users\kelly\Downloads\Blender\textures"
EARTH_TEX    = TEXTURE_BASE + r"\earth.jpg"
CLOUD_TEX    = TEXTURE_BASE + r"\clouds.jpg"
NIGHT_TEX    = TEXTURE_BASE + r"\night.jpg"

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _remove_named_nodes(nodes, name_list):
    """Remove enhancement nodes by name so the script is re-runnable."""
    for name in name_list:
        n = nodes.get(name)
        if n:
            nodes.remove(n)


def _load_image(path, colorspace, label):
    """Load an image from disk with the given colorspace, or return None."""
    if os.path.exists(path):
        img = bpy.data.images.load(path, check_existing=True)
        img.colorspace_settings.name = colorspace
        print(f"   ✅ {label} loaded from disk")
        return img
    print(f"   ⚠  {label} not found at {path}")
    return None


# ─────────────────────────────────────────────────────────────────────────────
# TEXTURE EXTRACTION + COLOR ENHANCEMENT
# ─────────────────────────────────────────────────────────────────────────────

ENHANCEMENT_NODES = [
    "Earth_TexCoord",
    "Earth_Mapping",
    "Earth_TexEarth",
    "Earth_TexCloud",
    "Earth_TexNight",
    "Earth_HueSat",
    "Earth_Curves",
    "Earth_CloudMix",
    "Earth_Emit",
    "Earth_AddShader",
]


def extract_and_enhance(obj):
    # ── Locate or create the material ────────────────────────────────────────
    if obj.data.materials:
        mat = obj.data.materials[0]
        if mat is None:
            mat = bpy.data.materials.new("Earth_Mat")
            obj.data.materials[0] = mat
    else:
        mat = bpy.data.materials.new("Earth_Mat")
        obj.data.materials.append(mat)

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # ── Find key nodes ────────────────────────────────────────────────────────
    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out  = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)

    # Collect all existing TEX_IMAGE nodes for extraction
    existing_tex_nodes = [n for n in nodes if n.type == 'TEX_IMAGE']

    if bsdf is None:
        nodes.clear()
        out  = nodes.new("ShaderNodeOutputMaterial"); out.location  = (1000, 0)
        bsdf = nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (  600, 0)
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
        existing_tex_nodes = []
    if out is None:
        out = nodes.new("ShaderNodeOutputMaterial"); out.location = (1000, 0)

    # Earth surface properties — moderate roughness, ocean IOR, slight specularity
    bsdf.inputs["Roughness"].default_value          = 0.75
    bsdf.inputs["Specular IOR Level"].default_value = 0.05
    bsdf.inputs["Metallic"].default_value           = 0.0
    bsdf.inputs["IOR"].default_value                = 1.50
    bsdf.inputs["Alpha"].default_value              = 1.0

    # ── Extract textures from existing nodes ──────────────────────────────────
    # Try to identify which image is which by name/path, then fall back to disk
    img_earth = img_cloud = img_night = None

    for tex_n in existing_tex_nodes:
        if tex_n.image is None:
            continue
        fname = os.path.basename(tex_n.image.filepath).lower()
        if "earth" in fname or "day" in fname:
            img_earth = tex_n.image
            img_earth.colorspace_settings.name = 'sRGB'
            print(f"   Earth base extracted: {tex_n.image.name}")
        elif "cloud" in fname:
            img_cloud = tex_n.image
            img_cloud.colorspace_settings.name = 'sRGB'
            print(f"   Clouds extracted    : {tex_n.image.name}")
        elif "night" in fname or "light" in fname:
            img_night = tex_n.image
            img_night.colorspace_settings.name = 'Non-Color'
            print(f"   Night lights extracted: {tex_n.image.name}")

    # Disk fallback for any missing textures
    if img_earth is None:
        img_earth = _load_image(EARTH_TEX, 'sRGB',      "Earth base (earth.jpg)")
    if img_cloud is None:
        img_cloud = _load_image(CLOUD_TEX, 'sRGB',      "Clouds (clouds.jpg)")
    if img_night is None:
        img_night = _load_image(NIGHT_TEX, 'Non-Color', "Night lights (night.jpg)")

    # Remove all old texture nodes — we rebuild them cleanly
    for tex_n in existing_tex_nodes:
        nodes.remove(tex_n)

    # Disconnect anything already feeding Base Color / Normal / Surface
    for sock_name in ["Base Color", "Normal"]:
        for lnk in list(bsdf.inputs[sock_name].links):
            links.remove(lnk)

    # ── Remove previous enhancement nodes (safe to re-run) ───────────────────
    _remove_named_nodes(nodes, ENHANCEMENT_NODES)

    # ── Build enhancement chain ───────────────────────────────────────────────
    #
    #  TexCoord → Mapping → TexEarth  ─→ HueSat → Curves → CloudMix → Base Color → BSDF
    #                     ↘ TexCloud  ─────────────────────────↗ (Color2, Fac 0.10)
    #                     ↘ TexNight  ─→ Emission (Strength 0.5) ─→ AddShader → Output
    #                                                                    ↑
    #                                                              BSDF ─┘
    #

    def N(t, loc, name=None):
        node = nodes.new(t)
        node.location = loc
        if name:
            node.name  = name
            node.label = name
        return node

    tex_coord = N("ShaderNodeTexCoord", (-900, 100), "Earth_TexCoord")
    mapping   = N("ShaderNodeMapping",  (-700, 100), "Earth_Mapping")
    mapping.inputs["Scale"].default_value = (1.0, 1.0, 1.0)

    # Three texture nodes
    tex_earth = N("ShaderNodeTexImage", (-480,  200), "Earth_TexEarth")
    tex_cloud = N("ShaderNodeTexImage", (-480,  -80), "Earth_TexCloud")
    tex_night = N("ShaderNodeTexImage", (-480, -360), "Earth_TexNight")

    if img_earth: tex_earth.image = img_earth
    if img_cloud: tex_cloud.image = img_cloud
    if img_night: tex_night.image = img_night

    links.new(tex_coord.outputs["UV"],   mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_earth.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_cloud.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_night.inputs["Vector"])

    # HueSat — deepen oceans (blues), enrich landmass greens/browns
    hue_sat = N("ShaderNodeHueSaturation", (-180, 200), "Earth_HueSat")
    hue_sat.inputs["Hue"].default_value        = 0.50   # keep natural hues
    hue_sat.inputs["Saturation"].default_value = 1.30   # richer blues and greens
    hue_sat.inputs["Value"].default_value      = 1.00

    # RGB Curves — deepen deep ocean shadows, lift sunlit landmass
    curves = N("ShaderNodeRGBCurve", (60, 200), "Earth_Curves")
    c = curves.mapping.curves[3]
    c.points[0].location = (0.0, 0.0)
    c.points[1].location = (1.0, 1.0)
    c.points.new(0.25, 0.18)   # deepen ocean shadows
    c.points.new(0.72, 0.80)   # lift sunlit continents
    curves.mapping.update()

    # Cloud mix — subtle overlay (10%) on top of the enhanced day texture
    cloud_mix = N("ShaderNodeMixRGB", (320, 160), "Earth_CloudMix")
    cloud_mix.blend_type              = 'MIX'
    cloud_mix.use_clamp               = True
    cloud_mix.inputs["Fac"].default_value = 0.10   # clouds subtle, not dominant

    # Night emission — city lights glow on the dark side
    emit = N("ShaderNodeEmission", (320, -200), "Earth_Emit")
    emit.inputs["Strength"].default_value = 0.50   # visible but not bleeding

    add_sh = N("ShaderNodeAddShader", (580, 0), "Earth_AddShader")

    # ── Wire everything up ────────────────────────────────────────────────────
    if img_earth:
        links.new(tex_earth.outputs["Color"], hue_sat.inputs["Color"])
    links.new(hue_sat.outputs["Color"],   curves.inputs["Color"])
    links.new(curves.outputs["Color"],    cloud_mix.inputs["Color1"])  # earth = dominant
    if img_cloud:
        links.new(tex_cloud.outputs["Color"], cloud_mix.inputs["Color2"])  # clouds overlay
    links.new(cloud_mix.outputs["Color"], bsdf.inputs["Base Color"])

    if img_night:
        links.new(tex_night.outputs["Color"], emit.inputs["Color"])

    for lnk in list(out.inputs["Surface"].links):
        links.remove(lnk)
    links.new(bsdf.outputs["BSDF"],       add_sh.inputs[0])
    links.new(emit.outputs["Emission"],   add_sh.inputs[1])
    links.new(add_sh.outputs["Shader"],   out.inputs["Surface"])

    print("   ✅ Color enhancement applied:")
    print("      Sat ×1.30 (richer oceans/continents) | S-curve contrast")
    print("      Cloud overlay 10% | Night city lights emission 0.5")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def run():
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    obj = bpy.data.objects.get(OBJECT_NAME)
    if obj is None:
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            raise RuntimeError(
                f"❌ No object named '{OBJECT_NAME}' found. "
                "Select your Earth sphere and run again."
            )
        print(f"⚠  Using active object '{obj.name}' instead.")

    print("🌍 Earth — Texture Extract + Enhancement...")
    extract_and_enhance(obj)

    loc = tuple(round(v, 2) for v in obj.matrix_world.translation)
    print(f"   Earth world location  : {loc}")
    print()
    print("✅ Done!")
    print("   Textures used:")
    print(f"   - Day base   : {EARTH_TEX}")
    print(f"   - Clouds     : {CLOUD_TEX}")
    print(f"   - Night lights: {NIGHT_TEX}")
    print()
    print("   NOTE: Earth has no rings.")


run()
