"""
Earth + Moon — Realistic Proportions (v3 — fixed orbit ring alignment)
=======================================================================
Blender 5.0 — All values derived from real astronomical data.

FIX in v3:
  Two nested empties so the Moon always sits exactly on the ring:

    [Tilt_Empty]   ← fixed X rotation = inclination (5.145°)
        ├── [Spin_Empty]  ← animated Z rotation only
        │       └── Moon  ← placed at (orbit_bu, 0, 0) in local space
        └── Orbit_Ring    ← zero local rotation; inherits tilt from parent

  Previously the ring and the empty both had independent X tilts, which
  could drift apart. Now they share the exact same parent transform.

REAL DATA:
  Earth radius      6,371 km  = 1.0 BU
  Earth tilt        23.44°
  Moon radius       1,737.4 km = 0.2727 BU
  Moon orbit        384,400 km = 60.33 BU  (compressed to 9.05 BU with ORBIT_SCALE=0.15)
  Moon period       27.322 days = 274 frames
  Moon inclination  5.145°
  Earth spin        100 frames/rotation (slowed for visibility)

Object names needed in your scene:
  "Earth"  — sphere, radius ~1.0 BU
  "Moon"   — any sphere (script sets its scale)
"""

import bpy
import math

# ── SETTINGS ──────────────────────────────────────────────────────────────────
EARTH_RADIUS_BU   = 1.0
EARTH_TILT_DEG    = 23.44

MOON_ORBIT_RATIO  = 384400.0 / 6371.0   # 60.327
MOON_SIZE_RATIO   = 1737.4   / 6371.0   # 0.27270
MOON_TILT_DEG     = 5.145

MOON_SCALE_BOOST  = 1.0    # 1.0 = true scale; Moon is already 27% of Earth
ORBIT_SCALE       = 0.15   # compresses orbit for viewport; 1.0 = true 60 BU

MOON_ORBIT_FRAMES = 274    # frames per full Moon orbit
EARTH_SPIN_FRAMES = 100    # frames per Earth rotation (slowed for visibility)
ANIM_END          = 270    # ~3 Moon orbits

MOON_ORBIT_BU  = EARTH_RADIUS_BU * MOON_ORBIT_RATIO * ORBIT_SCALE     # ~9.05 BU
MOON_RADIUS_BU = EARTH_RADIUS_BU * MOON_SIZE_RATIO  * MOON_SCALE_BOOST # ~0.273 BU

# ─────────────────────────────────────────────────────────────────────────────


def remove_if_exists(name):
    obj = bpy.data.objects.get(name)
    if obj:
        bpy.data.objects.remove(obj, do_unlink=True)


def _set_linear(action):
    """Force LINEAR interpolation on every fcurve (supports Blender 3 and 4+)."""
    if action is None:
        return
    try:
        for layer in action.layers:
            for strip in layer.strips:
                for fc in strip.fcurves:
                    fc.extrapolation = 'LINEAR'
                    for kp in fc.keyframe_points:
                        kp.interpolation    = 'LINEAR'
                        kp.handle_left_type  = 'VECTOR'
                        kp.handle_right_type = 'VECTOR'
        return
    except AttributeError:
        pass
    try:
        for fc in action.fcurves:
            fc.extrapolation = 'LINEAR'
            for kp in fc.keyframe_points:
                kp.interpolation    = 'LINEAR'
                kp.handle_left_type  = 'VECTOR'
                kp.handle_right_type = 'VECTOR'
    except AttributeError:
        pass


def bake_spin_z(obj, period_frames, total_frames):
    """Pure Z spin — NO tilt. Tilt lives on the parent empty."""
    obj.animation_data_clear()
    obj.rotation_mode = 'XYZ'
    for frame in range(1, total_frames + 1):
        t = (frame - 1) % period_frames
        obj.rotation_euler = (0.0, 0.0, (t / period_frames) * math.tau)
        obj.keyframe_insert("rotation_euler", frame=frame)
    _set_linear(obj.animation_data.action if obj.animation_data else None)


def bake_spin_z_tilted(obj, period_frames, tilt_deg, total_frames):
    """Z spin with a fixed X tilt per frame (used for Earth's axial tilt + spin)."""
    obj.animation_data_clear()
    obj.rotation_mode = 'XYZ'
    ix = math.radians(tilt_deg)
    for frame in range(1, total_frames + 1):
        t = (frame - 1) % period_frames
        obj.rotation_euler = (ix, 0.0, (t / period_frames) * math.tau)
        obj.keyframe_insert("rotation_euler", frame=frame)
    _set_linear(obj.animation_data.action if obj.animation_data else None)


def make_orbit_ring(tilt_empty, orbit_bu, color):
    """
    Build the orbit ring as a child of tilt_empty with zero local rotation.
    It inherits the inclination from its parent, so it always matches the
    plane the Moon orbits in — no manual tilt needed.
    """
    name      = tilt_empty.name.replace("Tilt_Empty_", "")
    ring_name = f"Orbit_Ring_{name}"
    remove_if_exists(ring_name)

    bpy.ops.curve.primitive_nurbs_circle_add(radius=orbit_bu, location=(0, 0, 0))
    ring = bpy.context.active_object
    ring.name        = ring_name
    ring.hide_render = True
    ring.rotation_euler = (0, 0, 0)  # zero local — tilt from parent

    ring.parent = tilt_empty
    ring.matrix_parent_inverse = tilt_empty.matrix_world.inverted()

    ring.data.bevel_depth   = 0.008
    ring.data.use_fill_caps = False

    mat_name = f"OrbitMat_{name}"
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    out = mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
    em  = mat.node_tree.nodes.new("ShaderNodeEmission")
    em.inputs["Color"].default_value    = (*color, 1.0)
    em.inputs["Strength"].default_value = 1.5
    mat.node_tree.links.new(em.outputs["Emission"], out.inputs["Surface"])
    ring.data.materials.clear()
    ring.data.materials.append(mat)


def setup_moon(moon, name, orbit_bu, moon_radius_bu, orbit_frames, tilt_deg, color):
    """
    Build two-empty hierarchy:
      Tilt_Empty (fixed incl.) → Spin_Empty (animated Z) → Moon at X=orbit_bu
      Tilt_Empty               → Orbit_Ring (inherits tilt, zero local rotation)
    """
    tilt_name = f"Tilt_Empty_{name}"
    spin_name = f"Spin_Empty_{name}"
    remove_if_exists(tilt_name)
    remove_if_exists(spin_name)

    # Scale moon
    moon.scale = (moon_radius_bu, moon_radius_bu, moon_radius_bu)
    moon.constraints.clear()
    moon.animation_data_clear()
    if moon.parent:
        bpy.context.view_layer.objects.active = moon
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

    # Tilt empty — static inclination only
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    tilt_empty = bpy.context.active_object
    tilt_empty.name = tilt_name
    tilt_empty.rotation_euler = (math.radians(tilt_deg), 0, 0)
    tilt_empty.animation_data_clear()

    # Spin empty — animated Z rotation only, child of tilt empty
    bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))
    spin_empty = bpy.context.active_object
    spin_empty.name = spin_name
    spin_empty.parent = tilt_empty
    spin_empty.matrix_parent_inverse = tilt_empty.matrix_world.inverted()
    bake_spin_z(spin_empty, orbit_frames, ANIM_END)

    # Moon parented to spin empty, offset along local X
    moon.parent = spin_empty
    moon.matrix_parent_inverse = spin_empty.matrix_world.inverted()
    moon.location = (orbit_bu, 0, 0)

    # Orbit ring parented to tilt empty
    make_orbit_ring(tilt_empty, orbit_bu, color)

    print(f"   {name}: orbit {orbit_bu:.3f} BU | radius {moon_radius_bu:.4f} BU | "
          f"incl {tilt_deg}° | {orbit_frames} frames/orbit")


def setup():
    scene = bpy.context.scene
    scene.frame_start = 1
    scene.frame_end   = ANIM_END

    earth = bpy.data.objects.get("Earth")
    moon  = bpy.data.objects.get("Moon")
    if not earth: raise RuntimeError("❌ No object named 'Earth'!")
    if not moon:  raise RuntimeError("❌ No object named 'Moon'!")

    # Earth
    earth.constraints.clear()
    earth.location = (0, 0, 0)
    earth.scale    = (EARTH_RADIUS_BU,) * 3
    print("Baking Earth spin...")
    bake_spin_z_tilted(earth, EARTH_SPIN_FRAMES, EARTH_TILT_DEG, ANIM_END)
    print(f"✅ Earth — 1 spin/{EARTH_SPIN_FRAMES} frames, tilt {EARTH_TILT_DEG}°")

    # Moon
    print("Baking Moon orbit...")
    setup_moon(
        moon          = moon,
        name          = "Moon",
        orbit_bu      = MOON_ORBIT_BU,
        moon_radius_bu= MOON_RADIUS_BU,
        orbit_frames  = MOON_ORBIT_FRAMES,
        tilt_deg      = MOON_TILT_DEG,
        color         = (0.85, 0.88, 0.95),
    )
    print(f"✅ Moon — {ANIM_END // MOON_ORBIT_FRAMES} full orbits over {ANIM_END} frames")

    scene.frame_set(1)
    print("\n🌍 Earth–Moon system ready! Press SPACEBAR.")
    print(f"   ORBIT_SCALE={ORBIT_SCALE} → Moon orbit = {MOON_ORBIT_BU:.2f} BU")
    print(f"   Adjust ORBIT_SCALE (line 34) to move Moon closer/further.")
    print(f"   Adjust EARTH_SPIN_FRAMES (line 37) to speed/slow Earth rotation.")


setup()