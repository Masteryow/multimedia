import bpy

EARTH_NAME    = "Earth"
EARTH_TEXTURE = r"C:\Users\kelly\Downloads\Blender\textures\earth.jpg"
CLOUD_TEXTURE = r"C:\Users\kelly\Downloads\Blender\textures\clouds.jpg"
NIGHT_TEXTURE = r"C:\Users\kelly\Downloads\Blender\textures\night.jpg"

earth = bpy.data.objects.get(EARTH_NAME)
if not earth:
    print("ERROR: Object not found!")
else:
    bpy.context.view_layer.objects.active = earth
    bpy.ops.object.shade_smooth()

    # ---- SUBDIVISION ----
    has_subsurf = any(m.type == 'SUBSURF' for m in earth.modifiers)
    if not has_subsurf:
        subsurf = earth.modifiers.new(name="Subdivision", type='SUBSURF')
        subsurf.levels = 3
        subsurf.render_levels = 4
        print("Subdivision Surface added")

    # ---- UV MAP ----
    if not earth.data.uv_layers:
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.sphere_project()
        bpy.ops.object.mode_set(mode='OBJECT')
        print("UV map created")

    # ---- MATERIAL ----
    if len(earth.data.materials) == 0:
        mat = bpy.data.materials.new(name="EarthMat")
        earth.data.materials.append(mat)
        print("Created new material")
    else:
        mat = earth.data.materials[0]

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    # ---- NODES ----
    output     = nodes.new("ShaderNodeOutputMaterial")
    add_shader = nodes.new("ShaderNodeAddShader")
    princip    = nodes.new("ShaderNodeBsdfPrincipled")
    mix        = nodes.new("ShaderNodeMixRGB")
    tex_earth  = nodes.new("ShaderNodeTexImage")
    tex_cloud  = nodes.new("ShaderNodeTexImage")
    tex_night  = nodes.new("ShaderNodeTexImage")
    emission   = nodes.new("ShaderNodeEmission")

    # ---- LOAD IMAGES ----
    tex_earth.image = bpy.data.images.load(EARTH_TEXTURE, check_existing=True)
    tex_cloud.image = bpy.data.images.load(CLOUD_TEXTURE, check_existing=True)
    tex_night.image = bpy.data.images.load(NIGHT_TEXTURE, check_existing=True)

    # ---- COLOR SPACE ----
    tex_earth.image.colorspace_settings.name = 'sRGB'
    tex_cloud.image.colorspace_settings.name = 'sRGB'
    tex_night.image.colorspace_settings.name = 'Non-Color'

    # ---- MATERIAL VALUES ----
    princip.inputs["Metallic"].default_value           = 0.0
    princip.inputs["Roughness"].default_value          = 0.75
    princip.inputs["IOR"].default_value                = 1.5
    princip.inputs["Alpha"].default_value              = 1.0
    princip.inputs["Specular IOR Level"].default_value = 0.05  # less glare

    mix.blend_type                  = 'MIX'
    mix.use_clamp                   = True
    mix.inputs["Fac"].default_value = 0.10  # clouds subtle

    emission.inputs["Strength"].default_value = 0.5  # night lights not bleeding

    # ---- NODE POSITIONS ----
    tex_earth.location  = (-500,  200)
    tex_cloud.location  = (-500, -100)
    tex_night.location  = (-500, -400)
    mix.location        = (-200,  100)
    princip.location    = (100,   200)
    emission.location   = (100,  -200)
    add_shader.location = (450,     0)
    output.location     = (700,     0)

    # ---- LINKS ----
    # earth → Color1 (dominant), clouds → Color2 (subtle overlay)
    links.new(tex_earth.outputs["Color"],   mix.inputs["Color1"])
    links.new(tex_cloud.outputs["Color"],   mix.inputs["Color2"])
    links.new(mix.outputs["Color"],         princip.inputs["Base Color"])

    # night lights → emission
    links.new(tex_night.outputs["Color"],   emission.inputs["Color"])

    # combine principled + emission
    links.new(princip.outputs["BSDF"],      add_shader.inputs[0])
    links.new(emission.outputs["Emission"], add_shader.inputs[1])
    links.new(add_shader.outputs["Shader"], output.inputs["Surface"])

    print("✅ Earth material applied!")
    print("👉 Press Z → Material Preview or Rendered to see result.")