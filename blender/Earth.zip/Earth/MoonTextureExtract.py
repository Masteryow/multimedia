"""
Moon (Earth's) — Texture Extract + Color Enhancement
=====================================================
Blender 5.0

Standalone script — does NOT require Moon.py to have run first.

What this does:
  1. Finds the existing Moon object (named 'Moon', or falls back to
     the active selection)
  2. Extracts the moon.jpg already in the material node tree
     (or loads from disk as fallback)
  3. Applies the full cinematic Moon pipeline:
       Texture → HueSat (desaturate, push slightly cool/blue-grey)
       → RGB Curves (deepen crater shadows, hold highlights)
       → Red + Green channel blend → Bump (strong crater relief)
       → Very faint cold blue emission (albedo scatter at terminator)

Nothing else is touched — no mesh rebuild, no animation, no rings
(the Moon has no rings).
Re-runnable: safe to run multiple times without duplicating nodes.

Moon surface notes:
  - Near-greyscale with a faint cool blue-grey undertone
  - Heavily cratered — strong bump, same approach as Mercury
  - Very low albedo (~12%) — dark ancient basalt maria
  - Tiny cold emission: faint bluish albedo scatter visible at terminator
  - Roughness 0.95 — fully matte regolith surface
"""

import bpy
import os

OBJECT_NAME  = "Moon"
TEXTURE_BASE = r"C:\Users\kelly\Downloads\Blender\textures"
MOON_TEX     = TEXTURE_BASE + r"\moon.jpg"

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _remove_named_nodes(nodes, name_list):
    """Remove enhancement nodes by name so the script is re-runnable."""
    for name in name_list:
        n = nodes.get(name)
        if n:
            nodes.remove(n)


# ─────────────────────────────────────────────────────────────────────────────
# TEXTURE EXTRACTION + COLOR ENHANCEMENT
# ─────────────────────────────────────────────────────────────────────────────

ENHANCEMENT_NODES = [
    "Moon_TexCoord",
    "Moon_Mapping",
    "Moon_TexImage",
    "Moon_HueSat",
    "Moon_Curves",
    "Moon_SepColor",
    "Moon_MixBump",
    "Moon_Bump",
    "Moon_LumMath",
    "Moon_Emit",
    "Moon_AddShader",
]


def extract_and_enhance(obj):
    # ── Locate or create the material ────────────────────────────────────────
    if obj.data.materials:
        mat = obj.data.materials[0]
        if mat is None:
            mat = bpy.data.materials.new("Moon_Mat")
            obj.data.materials[0] = mat
    else:
        mat = bpy.data.materials.new("Moon_Mat")
        obj.data.materials.append(mat)

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # ── Find key nodes ────────────────────────────────────────────────────────
    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out  = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
    tex  = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)

    if bsdf is None:
        nodes.clear()
        out  = nodes.new("ShaderNodeOutputMaterial"); out.location  = (900, 0)
        bsdf = nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (550, 0)
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    if out is None:
        out = nodes.new("ShaderNodeOutputMaterial"); out.location = (900, 0)

    # Moon surface: very matte, near-zero specular, faint dust sheen
    bsdf.inputs["Roughness"].default_value          = 0.95
    bsdf.inputs["Specular IOR Level"].default_value = 0.02
    bsdf.inputs["Metallic"].default_value           = 0.0
    try:
        bsdf.inputs["Sheen Weight"].default_value   = 0.04   # regolith dust feel
    except KeyError:
        pass

    # ── Remove previous enhancement nodes (safe to re-run) ───────────────────
    _remove_named_nodes(nodes, ENHANCEMENT_NODES)

    def N(t, loc, name=None):
        node = nodes.new(t)
        node.location = loc
        if name:
            node.name  = name
            node.label = name
        return node

    # ── Extract texture ───────────────────────────────────────────────────────
    image = None
    if tex and tex.image:
        image = tex.image
        if image.colorspace_settings.name != 'sRGB':
            image.colorspace_settings.name = 'sRGB'
        print(f"   Texture extracted from existing node: {image.name}")
        nodes.remove(tex)
    elif os.path.exists(MOON_TEX):
        image = bpy.data.images.load(MOON_TEX, check_existing=True)
        image.colorspace_settings.name = 'sRGB'
        print(f"   ✅ Texture loaded from disk: {MOON_TEX}")
    else:
        print(f"   ⚠  Texture not found at {MOON_TEX} — enhancement applied without texture")

    # Disconnect anything already feeding Base Color / Normal
    for sock_name in ["Base Color", "Normal"]:
        for lnk in list(bsdf.inputs[sock_name].links):
            links.remove(lnk)

    # ── Build enhancement chain ───────────────────────────────────────────────
    #
    #  TexCoord → Mapping → TexImage ──→ HueSat → Curves → Base Color → BSDF
    #                           │                                           │
    #                           └──→ SepColor (R, G) → MixBump → Bump → Normal
    #                                        │
    #                                      Red → LumMath (×0.018) → Emit strength
    #                                                    → Emit (cold blue)
    #                                                          │
    #                                                    AddShader ───────→ Output
    #

    tex_coord = N("ShaderNodeTexCoord", (-900, 100), "Moon_TexCoord")
    mapping   = N("ShaderNodeMapping",  (-700, 100), "Moon_Mapping")
    mapping.inputs["Scale"].default_value = (1.0, 1.0, 1.0)

    tex_node  = N("ShaderNodeTexImage", (-450, 100), "Moon_TexImage")
    if image:
        tex_node.image = image

    links.new(tex_coord.outputs["UV"],   mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_node.inputs["Vector"])

    # HueSat — nearly greyscale, slight cool blue-grey push
    # Moon has a faint blue-grey cast in true colour (highland anorthosite)
    hue_sat = N("ShaderNodeHueSaturation", (-150, 100), "Moon_HueSat")
    hue_sat.inputs["Hue"].default_value        = 0.58   # push slightly cool
    hue_sat.inputs["Saturation"].default_value = 0.25   # nearly greyscale
    hue_sat.inputs["Value"].default_value      = 0.95   # slightly dim (low albedo)

    # RGB Curves — crater shadow depth + highlight hold
    curves = N("ShaderNodeRGBCurve", (80, 100), "Moon_Curves")
    c = curves.mapping.curves[3]
    c.points[0].location = (0.0, 0.00)
    c.points[1].location = (0.4, 0.36)   # deepen shadow craters
    c.points.new(0.80, 0.85)             # hold bright highland rims
    curves.mapping.update()

    # Separate Color — Red + Green channel bump blend
    # Red: bright on highlands, dark in maria basalt → excellent height map
    # Green: extra variation for subtle highland texture
    sep = N("ShaderNodeSeparateColor", (-450, -200), "Moon_SepColor")

    mix_bump = N("ShaderNodeMixRGB", (-200, -200), "Moon_MixBump")
    mix_bump.blend_type = 'MIX'
    mix_bump.inputs["Fac"].default_value = 0.50

    # Bump — strong crater relief (comparable to Mercury)
    bump = N("ShaderNodeBump", (80, -200), "Moon_Bump")
    bump.inputs["Strength"].default_value = 0.80
    bump.inputs["Distance"].default_value = 0.08

    # Emission — barely perceptible cold blue albedo scatter at terminator
    # The Moon's regolith has a very faint retroreflective glow in reality
    lum_math = N("ShaderNodeMath", (-200, -380), "Moon_LumMath")
    lum_math.operation = 'MULTIPLY'
    lum_math.inputs[1].default_value = 0.018   # extremely subtle

    emit = N("ShaderNodeEmission", (80, -380), "Moon_Emit")
    emit.inputs["Color"].default_value = (0.80, 0.88, 1.00, 1.0)  # cold blue-white

    add_sh = N("ShaderNodeAddShader", (750, -100), "Moon_AddShader")

    # ── Wire everything up ────────────────────────────────────────────────────
    if image:
        links.new(tex_node.outputs["Color"],  hue_sat.inputs["Color"])
        links.new(tex_node.outputs["Color"],  sep.inputs["Color"])

    links.new(hue_sat.outputs["Color"],   curves.inputs["Color"])
    links.new(curves.outputs["Color"],    bsdf.inputs["Base Color"])

    links.new(sep.outputs["Red"],         mix_bump.inputs["Color1"])
    links.new(sep.outputs["Green"],       mix_bump.inputs["Color2"])
    links.new(mix_bump.outputs["Color"],  bump.inputs["Height"])
    links.new(bump.outputs["Normal"],     bsdf.inputs["Normal"])

    links.new(sep.outputs["Red"],         lum_math.inputs[0])
    links.new(lum_math.outputs["Value"],  emit.inputs["Strength"])

    for lnk in list(out.inputs["Surface"].links):
        links.remove(lnk)
    links.new(bsdf.outputs["BSDF"],       add_sh.inputs[0])
    links.new(emit.outputs["Emission"],   add_sh.inputs[1])
    links.new(add_sh.outputs["Shader"],   out.inputs["Surface"])

    print("   ✅ Color enhancement applied:")
    print("      Sat ×0.25 cool blue-grey | Curve crater deepen")
    print("      Red+Green bump (strength 0.80) | Faint cold blue terminator glow")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def run():
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    obj = bpy.data.objects.get(OBJECT_NAME)
    if obj is None:
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            raise RuntimeError(
                f"❌ No object named '{OBJECT_NAME}' found. "
                "Select your Moon sphere and run again."
            )
        print(f"⚠  Using active object '{obj.name}' instead.")

    print("🌕 Moon — Texture Extract + Enhancement...")
    extract_and_enhance(obj)

    loc = tuple(round(v, 2) for v in obj.matrix_world.translation)
    print(f"   Moon world location   : {loc}")
    print()
    print("✅ Done!")
    print("   Surface properties:")
    print("   - Near-greyscale with faint cool blue-grey undertone")
    print("   - Low albedo — dark mare basalt / bright highland anorthosite")
    print("   - Heavy crater bump — Red+Green channel blend, strength 0.80")
    print("   - Very faint cold blue emission (retroreflective terminator scatter)")
    print()
    print("   NOTE: Earth's Moon has no rings.")
    print("   TIP: Single directional Sun light + subtle blue rim on dark side.")


run()
