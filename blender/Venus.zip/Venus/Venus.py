"""
Fix Venus Geometry — Smooth Sphere
====================================
Blender 5.0

The visible flat faces on Venus are caused by:
  1. Not enough geometry (low subdivision count)
  2. Flat shading instead of smooth shading

This script fixes both on the selected object ("Venus").

Run:
  1. Select your Venus sphere
  2. Open Text Editor → paste → Run Script (Alt+P)
"""

import bpy

# ── SETTINGS ──────────────────────────────────────────────────────────────────
OBJECT_NAME   = "Venus"   # change if your object has a different name
SUBDIV_LEVELS = 3          # 2 = decent, 3 = smooth, 4 = very smooth (heavy)
# ─────────────────────────────────────────────────────────────────────────────


def fix_venus_geometry():
    obj = bpy.data.objects.get(OBJECT_NAME)
    if obj is None:
        # Fall back to active object
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            raise RuntimeError(
                f"❌ No object named '{OBJECT_NAME}' found and no mesh is active.\n"
                "   Rename your Venus sphere to 'Venus' or select it and run again."
            )
        print(f"⚠  '{OBJECT_NAME}' not found — using active object '{obj.name}' instead.")

    if obj.type != 'MESH':
        raise RuntimeError(f"❌ '{obj.name}' is not a mesh object.")

    bpy.context.view_layer.objects.active = obj

    # ── 1. Remove any existing Subdivision Surface modifiers ──────────────────
    for mod in list(obj.modifiers):
        if mod.type == 'SUBSURF':
            obj.modifiers.remove(mod)
            print(f"   Removed existing SubSurf modifier.")

    # ── 2. Add a fresh Subdivision Surface ────────────────────────────────────
    subsurf = obj.modifiers.new(name="Subdivision", type='SUBSURF')
    subsurf.subdivision_type = 'CATMULL_CLARK'
    subsurf.levels            = SUBDIV_LEVELS      # viewport
    subsurf.render_levels     = SUBDIV_LEVELS + 1  # render gets one extra level
    subsurf.use_limit_surface = True
    print(f"   Added Subdivision Surface — viewport level {SUBDIV_LEVELS}, "
          f"render level {SUBDIV_LEVELS + 1}.")

    # ── 3. Smooth shading ─────────────────────────────────────────────────────
    # Set every polygon to smooth
    for poly in obj.data.polygons:
        poly.use_smooth = True
    obj.data.update()
    print("   Applied smooth shading to all faces.")

    # ── 4. Auto Smooth (sharp edges only where angle > threshold) ─────────────
    # In Blender 4+ auto smooth is a modifier; in 3.x it's a mesh property.
    try:
        # Blender 4.1+ approach — add Smooth by Angle modifier
        smooth_mod = obj.modifiers.new(name="Smooth by Angle", type='SMOOTH_BY_ANGLE')
        smooth_mod.angle = 3.14159   # 180° — everything smooth, no hard edges
        print("   Added 'Smooth by Angle' modifier (Blender 4.1+ style).")
    except Exception:
        # Blender 3.x fallback — use_auto_smooth on mesh data
        try:
            obj.data.use_auto_smooth = True
            obj.data.auto_smooth_angle = 3.14159
            print("   Enabled Auto Smooth on mesh (Blender 3.x style).")
        except Exception as e:
            print(f"   ⚠  Could not set auto smooth: {e}")

    # ── 5. Recalculate normals ─────────────────────────────────────────────────
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')
    print("   Recalculated normals (outside).")

    print()
    print(f"✅  Venus geometry fixed!")
    print(f"   Object        : {obj.name}")
    print(f"   SubDiv levels : {SUBDIV_LEVELS} (viewport) / {SUBDIV_LEVELS + 1} (render)")
    print(f"   Shading       : Smooth")
    print()
    print("   💡 Tips:")
    print("      • If it still looks faceted in render, increase SUBDIV_LEVELS to 4.")
    print("      • If it's too heavy, lower to 2 — still looks great with smooth shading.")
    print("      • The render level is always SUBDIV_LEVELS + 1 for cleaner output.")


fix_venus_geometry()