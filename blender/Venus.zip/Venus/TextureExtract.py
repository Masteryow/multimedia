"""
Venus — Texture Extract + Color Enhancement
============================================
Blender 5.0

Standalone script — Venus.py only fixes geometry (subdivision + smooth
shading). This script handles the full material pipeline.

What this does:
  1. Finds the existing Venus object (named 'Venus')
  2. Extracts the venus.jpg already in the material node tree
     (or loads from disk as fallback)
  3. Applies a physically-accurate Venus color pipeline:
       RGB → Luminance → Color Ramp (sulphur cloud palette)
       + HueSat (warm yellow-cream haze)
       + RGB Curves (lift highlights, deepen swirl shadows)
       + Atmospheric glow Emission (thick CO2 greenhouse — very warm)
       + Bump from luminance (cloud swirl relief)

Nothing else is touched — no mesh rebuild, no animation, no rings
(Venus has no rings).
Re-runnable: safe to run multiple times without duplicating nodes.

Venus surface/atmosphere notes:
  - We never see the surface — Venus is 100% cloud-covered
  - The jpg texture represents the cloud tops viewed in UV light (Mariner/Akatsuki)
  - Cloud deck: pale cream-yellow sulphuric acid droplets
  - Strong greenhouse effect — Venus glows with trapped heat even on night side
  - Slight limb brightening from thick atmosphere
  - NO specular — clouds are fully matte
"""

import bpy
import os

OBJECT_NAME  = "Venus"
TEXTURE_BASE = r"C:\Users\kelly\Downloads\Blender\textures"
VENUS_TEX    = TEXTURE_BASE + r"\venus.jpg"

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _remove_named_nodes(nodes, name_list):
    """Remove enhancement nodes by name so the script is re-runnable."""
    for name in name_list:
        n = nodes.get(name)
        if n:
            nodes.remove(n)


# ─────────────────────────────────────────────────────────────────────────────
# TEXTURE EXTRACTION + COLOR ENHANCEMENT
# ─────────────────────────────────────────────────────────────────────────────

ENHANCEMENT_NODES = [
    "Venus_TexCoord",
    "Venus_Mapping",
    "Venus_TexImage",
    "Venus_RGBtoBW",
    "Venus_Ramp",
    "Venus_HueSat",
    "Venus_Curves",
    "Venus_Emit",
    "Venus_AddShader",
    "Venus_Bump",
]


def extract_and_enhance(obj):
    # ── Locate or create the material ────────────────────────────────────────
    if obj.data.materials:
        mat = obj.data.materials[0]
        if mat is None:
            mat = bpy.data.materials.new("Venus_Mat")
            obj.data.materials[0] = mat
    else:
        mat = bpy.data.materials.new("Venus_Mat")
        obj.data.materials.append(mat)

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # ── Find key nodes ────────────────────────────────────────────────────────
    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out  = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
    tex  = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)

    if bsdf is None:
        nodes.clear()
        out  = nodes.new("ShaderNodeOutputMaterial"); out.location  = (1100, 0)
        bsdf = nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (  700, 0)
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    if out is None:
        out = nodes.new("ShaderNodeOutputMaterial"); out.location = (1100, 0)

    # Venus cloud deck properties — fully matte, thick scattering clouds
    bsdf.inputs["Roughness"].default_value          = 1.00   # fully matte cloud tops
    bsdf.inputs["Specular IOR Level"].default_value = 0.00   # zero specular — clouds
    bsdf.inputs["Metallic"].default_value           = 0.0

    # ── Remove previous enhancement nodes (safe to re-run) ───────────────────
    _remove_named_nodes(nodes, ENHANCEMENT_NODES)

    def N(t, loc, name=None):
        node = nodes.new(t)
        node.location = loc
        if name:
            node.name  = name
            node.label = name
        return node

    # ── Extract texture ───────────────────────────────────────────────────────
    image = None
    if tex and tex.image:
        image = tex.image
        print(f"   Texture extracted from existing node: {image.name}")
        nodes.remove(tex)
    elif os.path.exists(VENUS_TEX):
        image = bpy.data.images.load(VENUS_TEX, check_existing=True)
        print(f"   ✅ Texture loaded from disk: {VENUS_TEX}")
    else:
        print(f"   ⚠  Texture not found at {VENUS_TEX} — enhancement applied without texture")

    # Disconnect anything already feeding Base Color / Normal
    for sock_name in ["Base Color", "Normal"]:
        for lnk in list(bsdf.inputs[sock_name].links):
            links.remove(lnk)

    # ── Build enhancement chain ───────────────────────────────────────────────
    #
    #  TexCoord → Mapping → TexImage
    #                         │
    #                       RGB→BW ──→ ColorRamp (sulphur cloud palette)
    #                         │              │
    #                         │         HueSat (warm yellow-cream push)
    #                         │              │
    #                         │         RGB Curves (lift swirl highlights)
    #                         │              │
    #                         │     ─────────┬──── Base Color ──→ BSDF
    #                         │              │
    #                         │         Emission (warm amber glow — greenhouse)
    #                         │              │
    #                         │         AddShader ──────────────────→ Output
    #                         │
    #                       Bump (cloud swirl relief) ──→ Normal ──→ BSDF
    #

    tex_coord = N("ShaderNodeTexCoord", (-900, 200), "Venus_TexCoord")
    mapping   = N("ShaderNodeMapping",  (-700, 200), "Venus_Mapping")
    tex_node  = N("ShaderNodeTexImage", (-480, 200), "Venus_TexImage")
    if image:
        tex_node.image = image

    links.new(tex_coord.outputs["UV"],   mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_node.inputs["Vector"])

    # RGB → BW — strip native jpg hue (often shows false colour from UV imaging)
    # Keep only cloud swirl luminance detail
    rgb_to_bw = N("ShaderNodeRGBToBW", (-220, 200), "Venus_RGBtoBW")

    # Sulphuric acid cloud palette:
    #   dark  → warm brownish-yellow (thick lower cloud deck shadow)
    #   mid   → pale cream-yellow (main cloud tops)
    #   bright → near-white (highest, thinnest cloud wisps)
    ramp = N("ShaderNodeValToRGB", (20, 200), "Venus_Ramp")
    cr   = ramp.color_ramp
    cr.interpolation = 'EASE'
    cr.elements[0].position = 0.00; cr.elements[0].color = (0.38, 0.22, 0.06, 1.0)  # warm dark brown
    cr.elements[1].position = 1.00; cr.elements[1].color = (0.98, 0.94, 0.78, 1.0)  # near-white cream
    e = cr.elements.new(0.30); e.color = (0.70, 0.52, 0.18, 1.0)   # mid yellow-brown
    e = cr.elements.new(0.58); e.color = (0.88, 0.76, 0.48, 1.0)   # pale golden yellow
    e = cr.elements.new(0.80); e.color = (0.94, 0.88, 0.66, 1.0)   # cream-white

    # HueSat — push warmth into the yellow-orange family
    hue_sat = N("ShaderNodeHueSaturation", (280, 200), "Venus_HueSat")
    hue_sat.inputs["Hue"].default_value        = 0.53   # warm yellow-orange lane
    hue_sat.inputs["Saturation"].default_value = 1.20   # vivid sulphur clouds
    hue_sat.inputs["Value"].default_value      = 1.00

    # RGB Curves — lift cloud highlights (swirl wisps), deepen band shadows
    curves = N("ShaderNodeRGBCurve", (480, 200), "Venus_Curves")
    c = curves.mapping.curves[3]
    c.points[0].location = (0.0, 0.0)
    c.points[1].location = (1.0, 1.0)
    c.points.new(0.30, 0.22)   # deepen lower cloud shadow bands
    c.points.new(0.70, 0.82)   # lift upper wisp highlights
    curves.mapping.update()

    # Emission — Venus's extreme greenhouse effect (737 K surface)
    # Even the cloud tops glow with infrared heat re-emission
    # Warm amber-orange: hotter than Mercury despite being farther from Sun
    emit = N("ShaderNodeEmission", (550, -100), "Venus_Emit")
    emit.inputs["Color"].default_value    = (1.00, 0.55, 0.12, 1.0)  # hot amber glow
    emit.inputs["Strength"].default_value = 0.06                      # perceptible but subtle

    add_sh = N("ShaderNodeAddShader", (750, 100), "Venus_AddShader")

    # Bump — cloud swirl and band relief
    bump = N("ShaderNodeBump", (550, -250), "Venus_Bump")
    bump.inputs["Strength"].default_value = 0.35   # moderate — cloud swirls visible
    bump.inputs["Distance"].default_value = 0.020

    # ── Wire everything up ────────────────────────────────────────────────────
    if image:
        links.new(tex_node.outputs["Color"], rgb_to_bw.inputs["Color"])
    links.new(rgb_to_bw.outputs["Val"],   ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"],      hue_sat.inputs["Color"])
    links.new(hue_sat.outputs["Color"],   curves.inputs["Color"])
    links.new(curves.outputs["Color"],    bsdf.inputs["Base Color"])
    links.new(curves.outputs["Color"],    emit.inputs["Color"])

    links.new(rgb_to_bw.outputs["Val"],   bump.inputs["Height"])
    links.new(bump.outputs["Normal"],     bsdf.inputs["Normal"])

    for lnk in list(out.inputs["Surface"].links):
        links.remove(lnk)
    links.new(bsdf.outputs["BSDF"],      add_sh.inputs[0])
    links.new(emit.outputs["Emission"],  add_sh.inputs[1])
    links.new(add_sh.outputs["Shader"],  out.inputs["Surface"])

    print("   ✅ Color enhancement applied:")
    print("      BW luminance → Sulphur cloud ramp | Sat ×1.20 warm yellow")
    print("      S-curve contrast | Hot amber greenhouse glow | Cloud swirl bump")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def run():
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    obj = bpy.data.objects.get(OBJECT_NAME)
    if obj is None:
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            raise RuntimeError(
                f"❌ No object named '{OBJECT_NAME}' found. "
                "Select your Venus sphere and run again."
            )
        print(f"⚠  Using active object '{obj.name}' instead.")

    print("🌕 Venus — Texture Extract + Enhancement...")
    extract_and_enhance(obj)

    loc = tuple(round(v, 2) for v in obj.matrix_world.translation)
    print(f"   Venus world location  : {loc}")
    print()
    print("✅ Done!")
    print("   Atmosphere simulated:")
    print("   - Sulphuric acid cloud tops — pale cream-yellow palette")
    print("   - Strong greenhouse emission — hottest planet (737 K surface)")
    print("   - Cloud swirl bump detail preserved from texture luminance")
    print("   - Fully matte (zero specular) — thick cloud scattering")
    print()
    print("   NOTE: Venus has no rings.")
    print("   TIP: Run Venus.py first if the sphere looks faceted.")


run()
