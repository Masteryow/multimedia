"""
Mercury Cinematic Material Setup for Blender
=============================================
Run this INSIDE Blender:
  1. Open Blender's Text Editor (top menu: Editor Type → Text Editor)
  2. Click "+ New", paste this entire script
  3. Click "Run Script" (or press Alt+P)

Make sure your Mercury sphere is SELECTED before running.
Update TEXTURE_PATH below to your actual file.
"""

import bpy
import os

# ── CHANGE THIS TO YOUR TEXTURE FILE ─────────────────────────────────────────
TEXTURE_PATH = r"C:\Users\kelly\Downloads\Blender\textures\mercury.jpg"
# ─────────────────────────────────────────────────────────────────────────────

SEGMENTS = 128
RINGS    = 64


def fix_mesh(obj):
    """Replace whatever low-poly mesh is on obj with a high-res UV sphere."""
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)

    # Save transforms
    loc   = obj.location.copy()
    rot   = obj.rotation_euler.copy()
    scale = obj.scale.copy()

    # Nuke old modifiers
    obj.modifiers.clear()

    # Rebuild mesh in edit mode
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.delete(type='VERT')

    bpy.ops.mesh.primitive_uv_sphere_add(
        segments   = SEGMENTS,
        ring_count = RINGS,
        radius     = 1.0,
        location   = (0, 0, 0),
    )

    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.faces_shade_smooth()
    bpy.ops.object.mode_set(mode='OBJECT')

    # Restore transforms
    obj.location       = loc
    obj.rotation_euler = rot
    obj.scale          = scale

    # Recalculate normals
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    print(f"✅  Mesh replaced: UV Sphere {SEGMENTS}×{RINGS} ({SEGMENTS * RINGS:,} faces), smooth shading applied.")


def build_mercury_material(texture_path: str):
    obj = bpy.context.active_object
    if obj is None or obj.type != 'MESH':
        raise RuntimeError("Select your Mercury sphere first, then run the script.")

    # ── Fix low-poly silhouette first ─────────────────────────────────────────
    fix_mesh(obj)

    # ── Create / reuse material ───────────────────────────────────────────────
    mat_name = "Mercury_Cinematic"
    mat = bpy.data.materials.get(mat_name) or bpy.data.materials.new(mat_name)
    mat.use_nodes = True
    obj.data.materials.clear()
    obj.data.materials.append(mat)

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    def N(bl_type, loc):
        n = nodes.new(bl_type)
        n.location = loc
        return n

    # ── Nodes ──────────────────────────────────────────────────────────────────

    out        = N("ShaderNodeOutputMaterial",        (1000,   0))

    bsdf       = N("ShaderNodeBsdfPrincipled",        ( 580,   0))
    bsdf.inputs["Roughness"].default_value           = 0.95
    bsdf.inputs["Specular IOR Level"].default_value  = 0.02
    bsdf.inputs["Sheen Weight"].default_value        = 0.04
    bsdf.inputs["Metallic"].default_value            = 0.0

    tex_coord  = N("ShaderNodeTexCoord",              (-950,   0))
    mapping    = N("ShaderNodeMapping",               (-750,   0))
    mapping.inputs["Scale"].default_value            = (1, 1, 1)

    tex_color  = N("ShaderNodeTexImage",              (-500, 120))
    tex_color.label = "Mercury Base Color"
    if os.path.exists(texture_path):
        img = bpy.data.images.load(texture_path, check_existing=True)
        tex_color.image = img
    else:
        print(f"⚠  Texture not found: {texture_path}")
        print("   The material will still be created — add texture manually.")

    hue_sat    = N("ShaderNodeHueSaturation",         (-200, 120))
    hue_sat.inputs["Hue"].default_value          = 0.52
    hue_sat.inputs["Saturation"].default_value   = 0.30
    hue_sat.inputs["Value"].default_value        = 0.85

    rgb_curves = N("ShaderNodeRGBCurve",              ( 50,  120))
    c = rgb_curves.mapping.curves[3]
    c.points[0].location = (0.0,  0.0)
    c.points[1].location = (0.4,  0.35)
    c.points.new(0.85, 0.92)
    rgb_curves.mapping.update()

    mix_tint   = N("ShaderNodeMixRGB",               ( 280,  120))
    mix_tint.blend_type = 'MULTIPLY'
    mix_tint.inputs["Fac"].default_value         = 0.18
    mix_tint.inputs["Color2"].default_value      = (0.72, 0.66, 0.60, 1.0)

    sep_rgb    = N("ShaderNodeSeparateColor",         (-500, -180))
    invert     = N("ShaderNodeInvert",                (-250, -180))
    invert.inputs["Fac"].default_value = 0.35

    mix_bump   = N("ShaderNodeMixRGB",               ( -50, -180))
    mix_bump.blend_type = 'MIX'
    mix_bump.inputs["Fac"].default_value = 0.5

    bump       = N("ShaderNodeBump",                  ( 200, -180))
    bump.inputs["Strength"].default_value  = 0.80
    bump.inputs["Distance"].default_value  = 0.08

    # ── Wire everything up ────────────────────────────────────────────────────

    links.new(tex_coord.outputs["UV"],       mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"],     tex_color.inputs["Vector"])
    links.new(mapping.outputs["Vector"],     sep_rgb.inputs["Color"])

    links.new(tex_color.outputs["Color"],    hue_sat.inputs["Color"])
    links.new(hue_sat.outputs["Color"],      rgb_curves.inputs["Color"])
    links.new(rgb_curves.outputs["Color"],   mix_tint.inputs["Color1"])
    links.new(mix_tint.outputs["Color"],     bsdf.inputs["Base Color"])

    links.new(tex_color.outputs["Color"],    sep_rgb.inputs["Color"])
    links.new(sep_rgb.outputs["Red"],        invert.inputs["Color"])
    links.new(sep_rgb.outputs["Red"],        mix_bump.inputs["Color1"])
    links.new(invert.outputs["Color"],       mix_bump.inputs["Color2"])
    links.new(mix_bump.outputs["Color"],     bump.inputs["Height"])
    links.new(bump.outputs["Normal"],        bsdf.inputs["Normal"])

    links.new(bsdf.outputs["BSDF"],          out.inputs["Surface"])

    print("✅  Mercury_Cinematic material applied successfully!")
    print()
    print("   🪨  Real Mercury surface properties applied:")
    print("       • Dark dull gray with faint brownish tint")
    print("       • Very low albedo (7%) — nearly as dark as coal")
    print("       • Heavy crater bump (more cratered than Mars)")
    print("       • No atmosphere emission (airless world)")
    print()
    print("   💡  Render tips:")
    print("       • Single strong Sun/Point light (Mercury is close to the Sun)")
    print("       • Very low ambient — no atmosphere scattering")
    print("       • Black background, Cycles, ≥128 samples")


build_mercury_material(TEXTURE_PATH)