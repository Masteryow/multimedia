"""
Mercury — Texture Extract + Color Enhancement
=============================================
Blender 5.0

Standalone script — does NOT require Mercury.py to have run first.

What this does:
  1. Finds the existing Mercury object (named 'Mercury', or falls back
     to the active selection)
  2. Extracts the mercury.jpg already in the material node tree
     (or loads from disk as fallback)
  3. Applies the full cinematic Mercury pipeline:
       Texture → HueSat (desaturate, dark-gray with faint warm tint)
       → RGB Curves (deep shadows, lifted near-whites for sunlit craters)
       → MixRGB Multiply tint (warm lunar-gray tone)
       → Red channel + Inverted Red blend → Bump (heavy crater relief)
  4. No emission — Mercury is airless, no atmosphere glow

Nothing else is touched — no mesh rebuild, no animation, no rings
(Mercury has no rings).
Re-runnable: safe to run multiple times without duplicating nodes.

Mercury surface notes:
  - Extremely dark — albedo ~0.07 (nearly as dark as coal)
  - Dull grey-brown, almost monochrome — very low saturation
  - Heavily cratered — strongest bump of any inner planet
  - NO atmosphere — no emission, no scattering, no fill
  - Harsh terminator: extreme contrast between sunlit and dark sides
"""

import bpy
import os

OBJECT_NAME  = "Mercury"
TEXTURE_BASE = r"C:\Users\kelly\Downloads\Blender\textures"
MERCURY_TEX  = TEXTURE_BASE + r"\mercury.jpg"

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _remove_named_nodes(nodes, name_list):
    """Remove enhancement nodes by name so the script is re-runnable."""
    for name in name_list:
        n = nodes.get(name)
        if n:
            nodes.remove(n)


# ─────────────────────────────────────────────────────────────────────────────
# TEXTURE EXTRACTION + COLOR ENHANCEMENT
# ─────────────────────────────────────────────────────────────────────────────

ENHANCEMENT_NODES = [
    "Mercury_TexCoord",
    "Mercury_Mapping",
    "Mercury_TexImage",
    "Mercury_HueSat",
    "Mercury_Curves",
    "Mercury_Tint",
    "Mercury_SepColor",
    "Mercury_Invert",
    "Mercury_MixBump",
    "Mercury_Bump",
]


def extract_and_enhance(obj):
    # ── Locate or create the material ────────────────────────────────────────
    if obj.data.materials:
        mat = obj.data.materials[0]
        if mat is None:
            mat = bpy.data.materials.new("Mercury_Mat")
            obj.data.materials[0] = mat
    else:
        mat = bpy.data.materials.new("Mercury_Mat")
        obj.data.materials.append(mat)

    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # ── Find key nodes ────────────────────────────────────────────────────────
    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out  = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
    tex  = next((n for n in nodes if n.type == 'TEX_IMAGE'), None)

    if bsdf is None:
        nodes.clear()
        out  = nodes.new("ShaderNodeOutputMaterial"); out.location  = (1000, 0)
        bsdf = nodes.new("ShaderNodeBsdfPrincipled"); bsdf.location = (  580, 0)
        links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    if out is None:
        out = nodes.new("ShaderNodeOutputMaterial"); out.location = (1000, 0)

    # Mercury surface: extremely rough, near-zero specular, airless
    bsdf.inputs["Roughness"].default_value          = 0.95
    bsdf.inputs["Specular IOR Level"].default_value = 0.02
    bsdf.inputs["Metallic"].default_value           = 0.0
    try:
        bsdf.inputs["Sheen Weight"].default_value   = 0.04   # faint regolith dust
    except KeyError:
        pass

    # ── Remove previous enhancement nodes (safe to re-run) ───────────────────
    _remove_named_nodes(nodes, ENHANCEMENT_NODES)

    def N(t, loc, name=None):
        node = nodes.new(t)
        node.location = loc
        if name:
            node.name  = name
            node.label = name
        return node

    # ── Extract texture ───────────────────────────────────────────────────────
    image = None
    if tex and tex.image:
        image = tex.image
        print(f"   Texture extracted from existing node: {image.name}")
        nodes.remove(tex)
    elif os.path.exists(MERCURY_TEX):
        image = bpy.data.images.load(MERCURY_TEX, check_existing=True)
        print(f"   ✅ Texture loaded from disk: {MERCURY_TEX}")
    else:
        print(f"   ⚠  Texture not found at {MERCURY_TEX} — enhancement applied without texture")

    # Disconnect anything already feeding Base Color / Normal
    for sock_name in ["Base Color", "Normal"]:
        for lnk in list(bsdf.inputs[sock_name].links):
            links.remove(lnk)

    # Also disconnect Surface output (no emission in Mercury)
    for lnk in list(out.inputs["Surface"].links):
        links.remove(lnk)

    # ── Build enhancement chain ───────────────────────────────────────────────
    #
    #  TexCoord → Mapping → TexImage ──→ HueSat → Curves → MixTint → Base Color → BSDF → Output
    #                           │
    #                           └──→ SepColor (Red) ─────────────→ MixBump → Bump → Normal → BSDF
    #                                              └── Invert ──→  MixBump
    #
    # No emission — Mercury is airless, no glow whatsoever.
    #

    tex_coord = N("ShaderNodeTexCoord", (-950, 100), "Mercury_TexCoord")
    mapping   = N("ShaderNodeMapping",  (-750, 100), "Mercury_Mapping")
    mapping.inputs["Scale"].default_value = (1.0, 1.0, 1.0)

    tex_node  = N("ShaderNodeTexImage", (-500, 120), "Mercury_TexImage")
    if image:
        tex_node.image = image

    links.new(tex_coord.outputs["UV"],   mapping.inputs["Vector"])
    links.new(mapping.outputs["Vector"], tex_node.inputs["Vector"])

    # HueSat — heavily desaturate; very faint warm hue nudge
    # Mercury is almost monochrome — albedo 7%, dark coal-like grey
    hue_sat = N("ShaderNodeHueSaturation", (-200, 120), "Mercury_HueSat")
    hue_sat.inputs["Hue"].default_value        = 0.52   # keep near neutral
    hue_sat.inputs["Saturation"].default_value = 0.30   # very low — almost greyscale
    hue_sat.inputs["Value"].default_value      = 0.85   # darken overall (low albedo)

    # RGB Curves — deepen shadows (harsh terminator), lift near-whites (sunlit rims)
    curves = N("ShaderNodeRGBCurve", (50, 120), "Mercury_Curves")
    c = curves.mapping.curves[3]
    c.points[0].location = (0.0, 0.00)
    c.points[1].location = (0.4, 0.35)   # darken midtones — low albedo
    c.points.new(0.85, 0.92)             # lift sunlit crater rims
    curves.mapping.update()

    # MixRGB Multiply — subtle warm grey tint (mineral dust on regolith)
    tint = N("ShaderNodeMixRGB", (280, 120), "Mercury_Tint")
    tint.blend_type = 'MULTIPLY'
    tint.inputs["Fac"].default_value       = 0.18
    tint.inputs["Color2"].default_value    = (0.72, 0.66, 0.60, 1.0)  # warm grey-brown

    # Separate Color — Red channel = best height map for crater relief
    sep = N("ShaderNodeSeparateColor", (-500, -180), "Mercury_SepColor")

    # Invert Red — dark craters become raised, rims become lower (creates rim profile)
    invert = N("ShaderNodeInvert", (-250, -180), "Mercury_Invert")
    invert.inputs["Fac"].default_value = 0.35

    # Mix Red + Inverted Red — combined gives sharp crater walls both up and down
    mix_bump = N("ShaderNodeMixRGB", (-50, -180), "Mercury_MixBump")
    mix_bump.blend_type = 'MIX'
    mix_bump.inputs["Fac"].default_value = 0.50

    # Bump — strongest of all inner planets (Mercury is the most cratered)
    bump = N("ShaderNodeBump", (200, -180), "Mercury_Bump")
    bump.inputs["Strength"].default_value = 0.80
    bump.inputs["Distance"].default_value = 0.08

    # ── Wire everything up ────────────────────────────────────────────────────
    if image:
        links.new(tex_node.outputs["Color"],  hue_sat.inputs["Color"])
        links.new(tex_node.outputs["Color"],  sep.inputs["Color"])

    links.new(mapping.outputs["Vector"],  sep.inputs["Color"])   # use UV for bump too
    if image:
        links.new(tex_node.outputs["Color"],  sep.inputs["Color"])

    links.new(hue_sat.outputs["Color"],   curves.inputs["Color"])
    links.new(curves.outputs["Color"],    tint.inputs["Color1"])
    links.new(tint.outputs["Color"],      bsdf.inputs["Base Color"])

    links.new(sep.outputs["Red"],         invert.inputs["Color"])
    links.new(sep.outputs["Red"],         mix_bump.inputs["Color1"])
    links.new(invert.outputs["Color"],    mix_bump.inputs["Color2"])
    links.new(mix_bump.outputs["Color"],  bump.inputs["Height"])
    links.new(bump.outputs["Normal"],     bsdf.inputs["Normal"])

    # Direct BSDF → Output (no emission — Mercury is airless)
    links.new(bsdf.outputs["BSDF"],       out.inputs["Surface"])

    print("   ✅ Color enhancement applied:")
    print("      Sat ×0.30 (near-greyscale) | Curve shadow deepen | Warm grey tint")
    print("      Red + Inverted-Red crater bump (strength 0.80) | No emission (airless)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def run():
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    obj = bpy.data.objects.get(OBJECT_NAME)
    if obj is None:
        obj = bpy.context.active_object
        if obj is None or obj.type != 'MESH':
            raise RuntimeError(
                f"❌ No object named '{OBJECT_NAME}' found. "
                "Select your Mercury sphere and run again."
            )
        print(f"⚠  Using active object '{obj.name}' instead.")

    print("🪨 Mercury — Texture Extract + Enhancement...")
    extract_and_enhance(obj)

    loc = tuple(round(v, 2) for v in obj.matrix_world.translation)
    print(f"   Mercury world location : {loc}")
    print()
    print("✅ Done!")
    print("   Surface properties applied:")
    print("   - Near-greyscale with faint warm grey-brown mineral tint")
    print("   - Very low albedo (0.07) — darkest inner planet")
    print("   - Heavy crater bump — Red + Inverted-Red channel blend")
    print("   - Zero emission — airless world, no atmospheric glow")
    print("   - Harsh sunlit/shadow terminator from low Specular IOR")
    print()
    print("   NOTE: Mercury has no rings.")
    print("   TIP: Use a single strong Sun light — no fill light needed.")


run()
